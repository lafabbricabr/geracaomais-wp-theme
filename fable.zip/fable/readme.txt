Documentation of theme is located in folder "_documentation".
Complete list of instructional videos are located here: http://quanticalabs.com/wp_themes2/fable/instructional-videos/
If you need more help, please use our Support Forum: http://support.quanticalabs.com/forum