<?php 
		get_header(); 
		
		get_template_part('single','content'); 

		get_footer(); 